import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, BookOpen, GraduationCap, Search, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'suggestion';
}

export function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Olá! Sou o assistente acadêmico da universidade. Como posso ajudá-lo hoje? Posso responder sobre cursos, matrículas, calendário acadêmico, bibliotecas e muito mais!',
      sender: 'bot',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const suggestedQuestions = [
    'Como fazer matrícula?',
    'Calendário acadêmico 2024',
    'Horário da biblioteca',
    'Programas de graduação',
    'Bolsas de estudo',
    'Contato secretaria'
  ];

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate bot response
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateBotResponse(inputValue),
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('matrícula')) {
      return 'Para fazer sua matrícula, acesse o portal do aluno com seu CPF e senha. O período de matrícula para 2024.1 é de 15 a 30 de janeiro. Documentos necessários: RG, CPF, comprovante de residência e histórico escolar.';
    }
    
    if (lowerInput.includes('calendário') || lowerInput.includes('calendario')) {
      return 'O calendário acadêmico 2024 está disponível no site oficial. Principais datas: Início das aulas: 05/02, Recesso junino: 20-30/06, Fim do semestre: 15/07. Consulte o portal para datas específicas de provas e trabalhos.';
    }
    
    if (lowerInput.includes('biblioteca')) {
      return 'Nossa biblioteca funciona de segunda a sexta das 7h às 22h, e sábados das 8h às 17h. Oferecemos acesso digital 24h, salas de estudo individual e em grupo, e acervo com mais de 100.000 volumes.';
    }
    
    if (lowerInput.includes('curso') || lowerInput.includes('graduação')) {
      return 'Oferecemos 45 cursos de graduação nas áreas de Exatas, Humanas e Biológicas. Nossos cursos mais procurados incluem Engenharia, Medicina, Direito, Administração e Ciência da Computação. Gostaria de saber sobre algum curso específico?';
    }
    
    if (lowerInput.includes('bolsa')) {
      return 'Temos diversos programas de bolsas: ProUni, FIES, bolsas de mérito acadêmico e assistência estudantil. Para mais informações, procure a secretaria acadêmica ou acesse nosso portal de bolsas online.';
    }
    
    return 'Obrigado pela sua pergunta! Nossa equipe acadêmica pode fornecer informações mais detalhadas. Entre em contato conosco pelo telefone (11) 3000-0000 ou visite a secretaria acadêmica de segunda a sexta, das 8h às 18h.';
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputValue(question);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto bg-background border rounded-xl shadow-lg">
      {/* Header */}
      <div className="p-6 border-b bg-gradient-to-r from-university-blue to-university-blue-dark text-white rounded-t-xl">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-full">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Assistente Acadêmico</h2>
            <p className="text-blue-100 text-sm">Sistema RAG - Universidade Federal</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-university-gold" />
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              Online
            </Badge>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.sender === 'bot' && (
                <div className="flex-shrink-0 w-8 h-8 bg-university-blue rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              
              <Card className={`max-w-[80%] p-4 ${
                message.sender === 'user' 
                  ? 'bg-chat-user border-university-blue/20' 
                  : 'bg-chat-bot border-border'
              }`}>
                <p className="text-sm leading-relaxed">{message.content}</p>
                <span className="text-xs text-muted-foreground mt-2 block">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </Card>

              {message.sender === 'user' && (
                <div className="flex-shrink-0 w-8 h-8 bg-university-gold rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          ))}
          
          {isTyping && (
            <div className="flex gap-3 justify-start">
              <div className="flex-shrink-0 w-8 h-8 bg-university-blue rounded-full flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <Card className="max-w-[80%] p-4 bg-chat-bot border-border">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-university-blue rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-university-blue rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-university-blue rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </Card>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Suggested Questions */}
      {messages.length === 1 && (
        <div className="p-4 border-t bg-muted/50">
          <div className="flex items-center gap-2 mb-3">
            <Search className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Perguntas sugeridas:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleSuggestedQuestion(question)}
                className="text-xs hover:bg-university-blue hover:text-white transition-colors"
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t bg-card">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite sua pergunta sobre a universidade..."
            className="flex-1 bg-chat-input border-border focus:border-university-blue"
            disabled={isTyping}
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping}
            className="bg-university-blue hover:bg-university-blue-dark text-white px-4"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2 text-center">
          Este assistente utiliza IA para fornecer informações acadêmicas. Para questões específicas, consulte a secretaria.
        </p>
      </div>
    </div>
  );
}

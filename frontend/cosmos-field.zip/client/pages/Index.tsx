import { useState } from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap, BookOpen, Users, Award, MessageCircle, Phone, Mail, MapPin, Clock, Sparkles, HelpCircle, ChevronDown, ChevronUp, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChatBot } from '@/components/ChatBot';
import { ThemeToggle } from '@/components/ThemeToggle';
import { FloatingChatButton } from '@/components/FloatingChatButton';

export default function Index() {
  const [showChat, setShowChat] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-university-blue/5">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-university-blue rounded-xl">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Universidade Federal</h1>
                <p className="text-sm text-muted-foreground">Assistente Acadêmico RAG</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="bg-university-green/10 text-university-green border-university-green/20">
                <div className="w-2 h-2 bg-university-green rounded-full mr-2 animate-pulse"></div>
                Sistema Online
              </Badge>
              <Button asChild variant="outline" size="sm" className="border-university-blue text-university-blue hover:bg-university-blue hover:text-white">
                <Link to="/admin">
                  <Shield className="w-4 h-4 mr-2" />
                  Admin
                </Link>
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {showChat ? (
        /* Chat Interface */
        <div className="container mx-auto px-4 py-6 h-[calc(100vh-80px)]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Chat Assistente Acadêmico</h2>
            <Button
              variant="outline"
              onClick={() => setShowChat(false)}
              className="border-university-blue text-university-blue hover:bg-university-blue hover:text-white"
            >
              Voltar ao Início
            </Button>
          </div>
          <div className="h-[calc(100%-4rem)]">
            <ChatBot />
          </div>
        </div>
      ) : (
        /* Landing Page */
        <main className="container mx-auto px-4 py-12">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-gradient-to-br from-university-blue to-university-blue-dark rounded-2xl shadow-lg">
                <Sparkles className="w-12 h-12 text-white" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-university-blue to-university-navy bg-clip-text text-transparent">
              Assistente Acadêmico
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Sistema RAG inteligente para responder suas dúvidas sobre a universidade. 
              Pergunte sobre cursos, matrículas, calendário acadêmico e muito mais!
            </p>
            <Button
              size="lg"
              onClick={() => setShowChat(true)}
              className="bg-university-blue hover:bg-university-blue-dark text-white px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all"
            >
              <MessageCircle className="w-6 h-6 mr-2" />
              Iniciar Conversa
            </Button>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            <Card className="border-border hover:border-university-blue/50 transition-colors">
              <CardHeader>
                <div className="p-2 bg-university-blue/10 rounded-lg w-fit">
                  <BookOpen className="w-6 h-6 text-university-blue" />
                </div>
                <CardTitle>Informações Acad��micas</CardTitle>
                <CardDescription>
                  Cursos, disciplinas, calendário acadêmico e regulamentos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Acesse informações atualizadas sobre todos os cursos de graduação e pós-graduação.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border hover:border-university-blue/50 transition-colors">
              <CardHeader>
                <div className="p-2 bg-university-gold/10 rounded-lg w-fit">
                  <Users className="w-6 h-6 text-university-gold" />
                </div>
                <CardTitle>Processos Estudantis</CardTitle>
                <CardDescription>
                  Matrícula, transferências, bolsas e documentos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Orientações completas sobre todos os processos administrativos estudantis.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border hover:border-university-blue/50 transition-colors">
              <CardHeader>
                <div className="p-2 bg-university-green/10 rounded-lg w-fit">
                  <Award className="w-6 h-6 text-university-green" />
                </div>
                <CardTitle>Serviços Universitários</CardTitle>
                <CardDescription>
                  Biblioteca, laboratórios, restaurante e esportes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Informações sobre todos os serviços e facilidades oferecidos pela universidade.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl font-bold text-university-blue mb-2">45+</div>
              <div className="text-sm text-muted-foreground">Cursos de Graduação</div>
            </div>
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl font-bold text-university-gold mb-2">25k+</div>
              <div className="text-sm text-muted-foreground">Estudantes</div>
            </div>
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl font-bold text-university-green mb-2">1.2k+</div>
              <div className="text-sm text-muted-foreground">Professores</div>
            </div>
            <div className="text-center p-6 bg-card rounded-xl border">
              <div className="text-3xl font-bold text-university-navy mb-2">95%</div>
              <div className="text-sm text-muted-foreground">Satisfação</div>
            </div>
          </div>

          {/* Floating Chat Button - positioned after stats */}
          {!showChat && (
            <div className="flex justify-center mb-16">
              <FloatingChatButton onChatClick={() => setShowChat(true)} />
            </div>
          )}

          {/* FAQ Section */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Perguntas Frequentes</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Encontre respostas rápidas para as principais dúvidas sobre nossa universidade
              </p>
            </div>

            <div className="max-w-4xl mx-auto space-y-4">
              {[
                {
                  question: "Como faço para me matricular na universidade?",
                  answer: "Para se matricular, primeiro você precisa ser aprovado no vestibular ou ENEM. Após aprovação, acesse o portal do aluno com seu CPF e senha fornecida. Complete o processo enviando os documentos obrigatórios: RG, CPF, histórico escolar do ensino médio, comprovante de residência e foto 3x4. O período de matrícula acontece duas vezes por ano: janeiro e julho."
                },
                {
                  question: "Quais são os prazos do calendário acadêmico 2024?",
                  answer: "1º Semestre: Matrículas de 15 a 30 de janeiro, início das aulas em 05 de fevereiro, término em 15 de julho. 2º Semestre: Matrículas de 15 a 30 de julho, início das aulas em 05 de agosto, término em 15 de dezembro. Temos ainda o recesso junino de 20 a 30 de junho e recesso de fim de ano de 20 de dezembro a 31 de janeiro."
                },
                {
                  question: "Como funciona o sistema de bolsas de estudo?",
                  answer: "Oferecemos diversas modalidades: ProUni (bolsas parciais e integrais), FIES (financiamento estudantil), bolsas de mérito acadêmico (para alunos com CR acima de 8.5), bolsas de assistência estudantil (critério socioeconômico) e bolsas de iniciação científica. Para se candidatar, procure a secretaria acadêmica ou acesse o portal de bolsas online."
                },
                {
                  question: "Qual é o horário de funcionamento da biblioteca?",
                  answer: "A biblioteca central funciona de segunda a sexta das 7h às 22h, e aos sábados das 8h às 17h. Temos acesso digital 24h através do portal online. Oferecemos: empréstimo de livros, salas de estudo individual e em grupo, computadores para pesquisa, acesso a bases de dados científicas e apoio bibliográfico para trabalhos acadêmicos."
                },
                {
                  question: "Como posso transferir meu curso para outra universidade?",
                  answer: "Para transferência externa, solicite na secretaria acadêmica: histórico escolar atualizado, programa das disciplinas cursadas, declaração de matrícula e nada consta financeiro. O processo leva até 30 dias úteis. Para transferência interna (mudança de curso), verifique vagas disponíveis, mantenha CR mínimo de 7.0 e cumpra pelo menos 2 semestres no curso atual."
                },
                {
                  question: "Quais serviços estão disponíveis no campus?",
                  answer: "Nosso campus oferece: biblioteca com acervo de 100.000+ volumes, laboratórios de informática e específicos por curso, restaurante universitário com refeições subsidiadas, centro de convivência, quadras esportivas, academia, centro médico, agência bancária, copiadora e estacionamento gratuito para estudantes."
                },
                {
                  question: "Como posso solicitar documentos acadêmicos?",
                  answer: "Documentos podem ser solicitados presencialmente na secretaria ou online pelo portal do aluno. Disponíveis: histórico escolar (R$ 15), declaração de matrícula (gratuito), diploma (R$ 50), certificados de cursos (R$ 20). Prazo de entrega: documentos simples em 3 dias úteis, histórico em 7 dias úteis, diploma em 30 dias úteis."
                },
                {
                  question: "Existe sistema de monitoria e apoio acadêmico?",
                  answer: "Sim! Temos programa de monitoria em disciplinas básicas, centro de apoio ao estudante com orientação psicopedagógica, tutoria para calouros, grupos de estudo coordenados por professores, laboratório de redação e matemática, e programa de nivelamento para estudantes com dificuldades."
                }
              ].map((faq, index) => (
                <Card key={index} className="border-border hover:border-university-blue/30 transition-colors">
                  <CardHeader
                    className="cursor-pointer"
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  >
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-left text-lg font-semibold pr-4">
                        {faq.question}
                      </CardTitle>
                      <div className="flex-shrink-0">
                        {openFaq === index ? (
                          <ChevronUp className="w-5 h-5 text-university-blue" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  {openFaq === index && (
                    <CardContent className="pt-0">
                      <p className="text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>

            <div className="text-center mt-8">
              <p className="text-muted-foreground mb-4">
                Não encontrou a resposta que procura?
              </p>
              <Button
                onClick={() => setShowChat(true)}
                variant="outline"
                className="border-university-blue text-university-blue hover:bg-university-blue hover:text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Pergunte ao Assistente
              </Button>
            </div>
          </div>

          {/* Contact Information */}
          <Card className="bg-gradient-to-r from-university-blue/5 to-university-navy/5 border-university-blue/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5" />
                Informações de Contato
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-university-blue/10 rounded-lg">
                    <Phone className="w-4 h-4 text-university-blue" />
                  </div>
                  <div>
                    <p className="font-medium">Telefone</p>
                    <p className="text-sm text-muted-foreground">(11) 3000-0000</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-university-blue/10 rounded-lg">
                    <Mail className="w-4 h-4 text-university-blue" />
                  </div>
                  <div>
                    <p className="font-medium">E-mail</p>
                    <p className="text-sm text-muted-foreground">secretaria@universidade.edu.br</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-university-blue/10 rounded-lg">
                    <Clock className="w-4 h-4 text-university-blue" />
                  </div>
                  <div>
                    <p className="font-medium">Horário</p>
                    <p className="text-sm text-muted-foreground">Seg-Sex: 8h às 18h</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      )}

      {/* Footer */}
      <footer className="border-t bg-card/50 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-3 mb-4 md:mb-0">
              <div className="p-1.5 bg-university-blue rounded-lg">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="font-medium">© 2024 Universidade Federal</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Sistema RAG desenvolvido para assistência acadêmica
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}
